#!/usr/bin/env bash
set -euo pipefail
# Run from tractor_turbo_android_project root after "npx cap add android".
SRC="resources/android"
RES="android/app/src/main/res"
for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "$RES/mipmap-$density"
  cp "$SRC/mipmap-$density/ic_launcher.png" "$RES/mipmap-$density/ic_launcher.png"
  cp "$SRC/mipmap-$density/ic_launcher_round.png" "$RES/mipmap-$density/ic_launcher_round.png"
done
mkdir -p "$RES/mipmap-anydpi-v26" "$RES/drawable" "$RES/values"
cp "$SRC/mipmap-anydpi-v26/ic_launcher.xml" "$RES/mipmap-anydpi-v26/ic_launcher.xml"
cp "$SRC/mipmap-anydpi-v26/ic_launcher_round.xml" "$RES/mipmap-anydpi-v26/ic_launcher_round.xml"
cp "$SRC/drawable/ic_launcher_foreground.png" "$RES/drawable/ic_launcher_foreground.png"
cp "$SRC/values/ic_launcher_colors.xml" "$RES/values/ic_launcher_colors.xml"
